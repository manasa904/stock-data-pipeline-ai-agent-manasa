"""
sql_renderer.py
Builds the two validation SQL scripts from a confirmed column split.
Pure string templating — no LLM call happens in this file. This is
what runs *after* the human has approved (or edited) the natural
key/audit classification, never before.
"""


def render_row_count_check(src: str, tgt: str) -> str:
    return f"""-- Row Count Check
SELECT 'src' AS source_type, COUNT(1) AS records_count FROM {src}
UNION ALL
SELECT 'tgt' AS source_type, COUNT(1) AS records_count FROM {tgt};
"""


def render_data_validation_check(src: str, tgt: str, business_columns: list) -> str:
    cols = ", ".join(business_columns)
    return f"""-- Data Validation Check
-- Natural key and audit columns are excluded from this comparison.
SELECT {cols} FROM {src}
EXCEPT
SELECT {cols} FROM {tgt}
UNION
SELECT {cols} FROM {tgt}
EXCEPT
SELECT {cols} FROM {src};
"""
