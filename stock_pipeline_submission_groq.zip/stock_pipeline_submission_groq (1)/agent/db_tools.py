"""
db_tools.py
Read-only database access for the agent — schema introspection and
bounded sample-row fetching only. There is deliberately no "run any
SELECT" capability here anymore: the agent's job is to look at schema
and a handful of sample rows, propose a column classification, and
(after human confirmation) hand off to a deterministic template
renderer. It never executes the validation query itself.

Table and schema names are always passed through psycopg2.sql.Identifier
for safe quoting — even though these values come from our own
list_tables()/get_columns() output rather than raw user input, quoting
identifiers properly is cheap insurance against injection.
"""

import psycopg2
import psycopg2.extras
from psycopg2 import sql


class Database:
    def __init__(self, config):
        self.config = config
        self.conn = psycopg2.connect(
            host=config.pg_host,
            port=config.pg_port,
            dbname=config.pg_database,
            user=config.pg_user,
            password=config.pg_password,
            sslmode="require",
        )
        # Belt-and-braces: read-only at the transaction level too, on
        # top of the DB role's own SELECT-only privileges.
        self.conn.set_session(readonly=True, autocommit=True)

    def close(self):
        self.conn.close()

    def list_tables(self, schema: str):
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s AND table_type = 'BASE TABLE'
                ORDER BY table_name
                """,
                (schema,),
            )
            return [row[0] for row in cur.fetchall()]

    def get_columns(self, schema: str, table: str):
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position
                """,
                (schema, table),
            )
            return [{"name": r[0], "type": r[1]} for r in cur.fetchall()]

    def get_primary_key(self, schema: str, table: str):
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT kcu.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                  ON tc.constraint_name = kcu.constraint_name
                 AND tc.table_schema = kcu.table_schema
                WHERE tc.constraint_type = 'PRIMARY KEY'
                  AND tc.table_schema = %s AND tc.table_name = %s
                """,
                (schema, table),
            )
            return [row[0] for row in cur.fetchall()]

    def get_sample_rows(self, schema: str, table: str, limit: int = 5):
        """Fetch a small, bounded sample of rows — not a general query
        tool. limit is clamped so this can never be used to pull a
        large amount of data regardless of what's requested."""
        limit = max(1, min(limit, 20))
        query = sql.SQL("SELECT * FROM {}.{} LIMIT %s").format(
            sql.Identifier(schema), sql.Identifier(table)
        )
        with self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(query, (limit,))
            return [dict(r) for r in cur.fetchall()]
