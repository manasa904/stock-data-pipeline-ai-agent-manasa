"""
classifier.py
The "classify_columns" tool is itself backed by a small, focused LLM
call — separate from the main orchestrator conversation. Keeping it
isolated means its prompt and output format can be tested and tuned
independently of the orchestrator's broader tool-use loop, and the
orchestrator never has to see the raw column/sample-row data directly —
only the classification result.

This function does not touch the database and does not touch the
orchestrator's conversation history. It receives column metadata and
sample rows (already fetched by the orchestrator via other tools) and
returns a structured NK / audit / business classification.
"""

import json
import re

from groq import Groq

CLASSIFIER_PROMPT = """You classify database columns for a data validation script.

Table: {schema}.{table}
Primary key columns (may be empty): {pk_columns}

Columns:
{columns_desc}

Sample rows (for context — look for patterns like timestamps or hashes
that column names/types alone might not make obvious):
{sample_desc}

Classify every column into exactly one of:
- NATURAL_KEY: columns that together uniquely identify a business record
  (use the primary key if one is given; otherwise infer from names/types,
  e.g. an id column, or a combination like symbol + year)
- AUDIT: technical/metadata columns that are not business data
  (created_at, updated_at, detected_at, load timestamps, row hashes,
  checksums, etl_* columns, etc.)
- BUSINESS_DATA: everything else — the real values worth comparing

Respond with ONLY a JSON object, no other text, no markdown fences:
{{"natural_key": ["col1"], "audit": ["col2"], "business_data": ["col3","col4"],
  "reasoning": "one short sentence explaining the natural key choice"}}
"""


def classify_columns(api_key: str, model: str, schema: str, table: str,
                      columns: list, primary_key: list, sample_rows: list) -> dict:
    client = Groq(api_key=api_key)

    columns_desc = "\n".join(f"- {c['name']} ({c['type']})" for c in columns)
    sample_desc = json.dumps(sample_rows[:3], default=str, indent=2) if sample_rows else "(no sample rows available)"

    prompt = CLASSIFIER_PROMPT.format(
        schema=schema,
        table=table,
        pk_columns=primary_key,
        columns_desc=columns_desc,
        sample_desc=sample_desc,
    )

    resp = client.chat.completions.create(
        model=model,
        max_tokens=500,
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    text = (resp.choices[0].message.content or "").strip()
    text = re.sub(r"^```(json)?|```$", "", text, flags=re.MULTILINE).strip()

    try:
        result = json.loads(text)
    except json.JSONDecodeError:
        # Fail safe: if the classifier ever returns something unparseable,
        # surface that clearly rather than silently guessing a split.
        return {
            "error": "Classifier returned an unparseable response.",
            "raw": text,
        }

    all_cols = {c["name"] for c in columns}
    classified = set(result.get("natural_key", [])) | set(result.get("audit", [])) | set(result.get("business_data", []))
    missing = all_cols - classified
    if missing:
        result.setdefault("business_data", []).extend(sorted(missing))
        result["note"] = f"Columns not classified by the model were defaulted to business_data: {sorted(missing)}"

    return result
