"""
tools.py
Tool schemas the orchestrator can call, plus the dispatcher that routes
each call to db_tools / classifier / sql_renderer / sql_writer.

The important thing in this file is render_sql_template's guard: it will
refuse to run unless AgentState shows a classification was proposed AND
a genuine new user turn has happened since. This is enforced in code,
not just requested in the system prompt — the model cannot render SQL
in the same turn it proposes a classification, no matter what it tries.
"""

from db_tools import Database
from classifier import classify_columns as run_classifier
from sql_renderer import render_row_count_check, render_data_validation_check
from sql_writer import save_sql


class AgentState:
    """Tracks the human-confirmation gate for one conversation."""

    def __init__(self):
        self.awaiting_confirmation = False
        self.confirmed_this_turn = False
        self.last_proposal = None  # {schema, table, natural_key, audit, business_data}

    def start_new_turn(self):
        """Call this once per incoming user message, before the tool
        loop runs. If a proposal was pending, this user message counts
        as the human's response to it — which is what unlocks
        render_sql_template for this turn only."""
        self.confirmed_this_turn = self.awaiting_confirmation


TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_table_columns",
            "description": "Look up column names, types, and primary key for a table.",
            "parameters": {
                "type": "object",
                "properties": {
                    "schema": {"type": "string"},
                    "table": {"type": "string"},
                },
                "required": ["schema", "table"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_sample_rows",
            "description": "Fetch a small sample of rows (max 20) from a table, for context when classifying columns.",
            "parameters": {
                "type": "object",
                "properties": {
                    "schema": {"type": "string"},
                    "table": {"type": "string"},
                    "limit": {"type": "integer", "description": "Default 5, max 20."},
                },
                "required": ["schema", "table"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "classify_columns",
            "description": (
                "Propose a classification of a table's columns into natural_key, "
                "audit, and business_data. This does NOT finalize anything — you "
                "must present the result to the user and get their confirmation "
                "or edits before calling render_sql_template."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "schema": {"type": "string"},
                    "table": {"type": "string"},
                },
                "required": ["schema", "table"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "render_sql_template",
            "description": (
                "Deterministically render and save the row count check and data "
                "validation check SQL files. Only call this AFTER the user has "
                "explicitly confirmed or edited the column classification in "
                "their most recent message — never in the same turn as "
                "classify_columns."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "src": {"type": "string", "description": "schema.table for source"},
                    "tgt": {"type": "string", "description": "schema.table for target"},
                    "business_columns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Confirmed list of business data columns to compare (NK and audit already excluded).",
                    },
                },
                "required": ["src", "tgt", "business_columns"],
            },
        },
    },
]


def dispatch(db: Database, config, state: AgentState, tool_name: str, tool_input: dict):
    try:
        if tool_name == "get_table_columns":
            schema, table = tool_input["schema"], tool_input["table"]
            return {
                "columns": db.get_columns(schema, table),
                "primary_key": db.get_primary_key(schema, table),
            }

        if tool_name == "get_sample_rows":
            limit = tool_input.get("limit", 5)
            rows = db.get_sample_rows(tool_input["schema"], tool_input["table"], limit)
            return {"rows": rows, "row_count_returned": len(rows)}

        if tool_name == "classify_columns":
            schema, table = tool_input["schema"], tool_input["table"]
            columns = db.get_columns(schema, table)
            pk = db.get_primary_key(schema, table)
            samples = db.get_sample_rows(schema, table, limit=3)

            result = run_classifier(
                api_key=config.groq_api_key,
                model=config.model,
                schema=schema, table=table,
                columns=columns, primary_key=pk, sample_rows=samples,
            )

            if "error" not in result:
                state.awaiting_confirmation = True
                state.last_proposal = {
                    "schema": schema, "table": table,
                    "natural_key": result.get("natural_key", []),
                    "audit": result.get("audit", []),
                    "business_data": result.get("business_data", []),
                }
            return result

        if tool_name == "render_sql_template":
            if not state.confirmed_this_turn:
                return {
                    "error": (
                        "Blocked: no confirmed classification for this turn. "
                        "You must present the classify_columns proposal to the "
                        "user as plain text and wait for their next message "
                        "before calling render_sql_template."
                    )
                }

            src, tgt = tool_input["src"], tool_input["tgt"]
            business_columns = tool_input["business_columns"]

            row_count_sql = render_row_count_check(src, tgt)
            data_val_sql = render_data_validation_check(src, tgt, business_columns)

            row_count_path = save_sql(config.output_dir, "row_count_check.sql", row_count_sql)
            data_val_path = save_sql(config.output_dir, "data_validation_check.sql", data_val_sql)

            # Reset the gate — a fresh classification + confirmation is
            # required before another render can happen.
            state.awaiting_confirmation = False
            state.confirmed_this_turn = False
            state.last_proposal = None

            return {
                "row_count_check_saved_to": row_count_path,
                "data_validation_check_saved_to": data_val_path,
                "row_count_check_sql": row_count_sql,
                "data_validation_check_sql": data_val_sql,
                "note": "These scripts were generated but not executed.",
            }

        return {"error": f"Unknown tool: {tool_name}"}

    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}
