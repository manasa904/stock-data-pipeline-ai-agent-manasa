"""
config.py
Connection settings and model configuration, read from environment
variables so credentials never live in source code.

These are loaded from a .env file in the agent/ folder (see .env.example
for the template) via python-dotenv, so you don't need to export them
in your shell every time.

Required variables (in .env):
    PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD
    GROQ_API_KEY

Additionally required for webapp.py (not needed for main.py):
    AGENT_PASSWORD   -- the password visitors must enter to use the chat
    SECRET_KEY       -- random string used to sign session cookies
                        generate one with:
                        python -c "import secrets; print(secrets.token_hex(32))"
"""

import os

from dotenv import load_dotenv

load_dotenv()


def _require(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise EnvironmentError(
            f"Missing required environment variable: {name}. "
            f"Set it in agent/.env (see .env.example) before running the agent."
        )
    return value


class Config:
    PGHOST = property(lambda self: _require("PGHOST"))

    def __init__(self):
        self.pg_host = _require("PGHOST")
        self.pg_port = int(os.environ.get("PGPORT", "5432"))
        self.pg_database = _require("PGDATABASE")
        self.pg_user = _require("PGUSER")
        self.pg_password = _require("PGPASSWORD")
        self.groq_api_key = _require("GROQ_API_KEY")
        self.model = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
        self.output_dir = os.environ.get("VALIDATION_OUTPUT_DIR", "./validation_output")

        # Only required when running webapp.py (the hosted chat UI), not
        # for the CLI (main.py) — kept optional here so main.py users
        # don't have to set them.
        self.agent_password = os.environ.get("AGENT_PASSWORD")
        self.secret_key = os.environ.get("SECRET_KEY")
