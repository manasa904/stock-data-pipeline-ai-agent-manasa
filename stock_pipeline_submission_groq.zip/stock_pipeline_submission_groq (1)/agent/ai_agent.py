"""
ai_agent.py
The orchestrator: owns conversation history and the tool-use loop.
Every incoming user message goes through AgentState.start_new_turn()
first — this is what turns "the user replied to my proposal" into a
one-turn permission slip for render_sql_template (see tools.py).

The orchestrator itself never writes SQL and never executes anything
against the database. Its job is: inspect schema, propose a
classification, present it in plain language, wait for confirmation,
then hand off to the deterministic renderer.
"""

import json

from groq import Groq

from tools import TOOLS, dispatch, AgentState

SYSTEM_PROMPT = """You are a data validation assistant for a PostgreSQL database.

Your job, when asked to validate a source table against a target table:

1. Call get_table_columns on both tables to see their schema.
2. Call get_sample_rows on the source table (a few rows is enough) to
   give the classifier useful context.
3. Call classify_columns to get a proposed split of columns into
   natural_key, audit, and business_data.
4. STOP. Present the proposed classification to the user in plain
   language — which columns you'd treat as the natural key, which as
   audit fields, and which as the real business data to compare — and
   ask them to confirm or edit it. Do not call any more tools in this
   same turn. This step is not optional and cannot be skipped: the
   render tool will refuse to run until the user has responded.
5. Only after the user confirms (or gives you edits, which you should
   incorporate) — call render_sql_template with the final business
   column list. This deterministically generates two files:
   - a row count check comparing src and tgt
   - a data validation check comparing the business columns only
   Neither query is executed. You are generating scripts, not results.
6. Summarize what was generated in plain language: what the two checks
   do, which columns were excluded and why, and where the files were
   saved. Do not claim to know whether the tables actually match —
   you never ran the queries, so you have no result to report.

If the user's message is an edit to your proposal (e.g. "also treat
column X as a natural key"), incorporate it directly into the
business_columns you pass to render_sql_template — you don't need to
call classify_columns again unless they ask you to reconsider from
scratch.

You only have read access to small samples of data and schema
metadata. You cannot run arbitrary queries and you cannot modify
anything.
"""


class ValidationAgent:
    def __init__(self, db, config):
        self.db = db
        self.config = config
        self.client = Groq(api_key=config.groq_api_key)
        self.history = []
        self.state = AgentState()

    def ask(self, user_message: str) -> str:
        self.state.start_new_turn()
        self.history.append({"role": "user", "content": user_message})

        while True:
            response = self.client.chat.completions.create(
                model=self.config.model,
                max_tokens=2000,
                messages=[{"role": "system", "content": SYSTEM_PROMPT}] + self.history,
                tools=TOOLS,
            )

            message = response.choices[0].message

            assistant_message = {"role": "assistant", "content": message.content}
            if message.tool_calls:
                assistant_message["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in message.tool_calls
                ]
            self.history.append(assistant_message)

            if response.choices[0].finish_reason != "tool_calls":
                return message.content or ""

            for tc in message.tool_calls:
                tool_input = json.loads(tc.function.arguments)
                result = dispatch(self.db, self.config, self.state, tc.function.name, tool_input)
                self.history.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": str(result),
                    }
                )
