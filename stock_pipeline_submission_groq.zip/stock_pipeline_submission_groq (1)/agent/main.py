"""
main.py
Interactive entry point. Run this, describe what you want validated
in plain language, and keep chatting — the agent remembers context,
so you can ask follow-ups like "now check symbol_map for duplicates"
without repeating table names.

Usage:
    python main.py

Then, for example:
    You: Compare target_schema.stock_yearly_summary_expected against
         target_schema.stock_yearly_summary and tell me what's different.
    You: Now do the same for source_schema.combined_stock_data vs
         source_schema.stock_metadata, joined on symbol.
    You: exit
"""

from config import Config
from db_tools import Database
from ai_agent import ValidationAgent


def main():
    print("Data validation agent — describe what you want validated.")
    print("Type 'exit' or 'quit' to stop.\n")

    config = Config()
    db = Database(config)
    agent = ValidationAgent(db, config)

    try:
        while True:
            user_message = input("You: ").strip()
            if not user_message:
                continue
            if user_message.lower() in ("exit", "quit"):
                break

            print("\nAgent: ", end="", flush=True)
            reply = agent.ask(user_message)
            print(reply, "\n")

    finally:
        db.close()


if __name__ == "__main__":
    main()
