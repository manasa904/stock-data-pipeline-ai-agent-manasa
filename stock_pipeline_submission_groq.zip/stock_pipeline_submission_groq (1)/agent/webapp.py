"""
webapp.py
Hosted web chat interface for the validation agent, built with Flask.

Compared to the original local-only version, this adds what public
hosting requires:
  - Password-gated login (session cookie, not a full user system —
    one shared password, intended for you + your mentor)
  - Rate limiting per visitor, to cap Groq API / DB query cost
    if the URL ever leaks or gets hit by a bot
  - Per-session conversation history, so multiple visitors don't share
    one chat thread
  - Served via gunicorn in production (see Procfile), not Flask's
    built-in dev server

Local run (for testing before deploy):
    python webapp.py
    open http://127.0.0.1:5000

Production (see README.md for full Render.com deployment steps):
    gunicorn webapp:app --workers 1
"""

import functools
import secrets

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from config import Config
from db_tools import Database
from ai_agent import ValidationAgent

config = Config()

if not config.agent_password or not config.secret_key:
    raise EnvironmentError(
        "webapp.py requires AGENT_PASSWORD and SECRET_KEY to be set "
        "(see config.py). These are separate from your database "
        "credentials — AGENT_PASSWORD is what visitors type to log "
        "into the chat page."
    )

app = Flask(__name__)
app.secret_key = config.secret_key

limiter = Limiter(get_remote_address, app=app, default_limits=["60 per hour"])

# Shared DB connection (single gunicorn worker, sync — see README for
# why this doesn't scale to concurrent traffic, and why that's fine here).
db = Database(config)

# One agent per browser session, so visitors don't share a conversation.
_agents = {}


def get_agent():
    sid = session.get("sid")
    if sid is None or sid not in _agents:
        sid = secrets.token_hex(16)
        session["sid"] = sid
        _agents[sid] = ValidationAgent(db, config)
    return _agents[sid]


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")  # slow down password guessing
def login():
    error = None
    if request.method == "POST":
        submitted = request.form.get("password", "")
        if secrets.compare_digest(submitted, config.agent_password):
            session["authenticated"] = True
            return redirect(url_for("index"))
        error = "Incorrect password."
    return render_template("login.html", error=error)


@app.route("/logout", methods=["POST"])
def logout():
    sid = session.get("sid")
    if sid in _agents:
        del _agents[sid]
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template("chat.html")


@app.route("/api/chat", methods=["POST"])
@login_required
@limiter.limit("20 per hour")  # caps Groq API + DB query cost per visitor
def chat():
    data = request.get_json(force=True)
    message = (data or {}).get("message", "").strip()
    if not message:
        return jsonify({"error": "Empty message"}), 400
    try:
        agent = get_agent()
        reply = agent.ask(message)
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 500


@app.route("/api/reset", methods=["POST"])
@login_required
def reset():
    agent = get_agent()
    agent.history = []
    return jsonify({"status": "cleared"})


if __name__ == "__main__":
    # Dev server only — production uses gunicorn (see Procfile / README)
    app.run(debug=False, port=5000)
