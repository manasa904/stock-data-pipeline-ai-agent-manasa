-- Data Validation Check
-- Natural key and audit columns are excluded from this comparison.
SELECT company_name, industry, trading_days, avg_open, avg_close, year_high, year_low, total_volume FROM target_schema.stock_yearly_summary_expected
EXCEPT
SELECT company_name, industry, trading_days, avg_open, avg_close, year_high, year_low, total_volume FROM target_schema.stock_yearly_summary
UNION
SELECT company_name, industry, trading_days, avg_open, avg_close, year_high, year_low, total_volume FROM target_schema.stock_yearly_summary
EXCEPT
SELECT company_name, industry, trading_days, avg_open, avg_close, year_high, year_low, total_volume FROM target_schema.stock_yearly_summary_expected;
