-- Row Count Check
SELECT 'src' AS source_type, COUNT(1) AS records_count FROM target_schema.stock_yearly_summary_expected
UNION ALL
SELECT 'tgt' AS source_type, COUNT(1) AS records_count FROM target_schema.stock_yearly_summary;
