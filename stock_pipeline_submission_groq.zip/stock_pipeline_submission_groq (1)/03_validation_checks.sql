-- =========================================================
-- STEP 3: Validation checks & mismatch report
-- Logs data-quality findings from the target table into a
-- persistent report table.
-- =========================================================

CREATE TABLE target_schema.mismatch_report (
    mismatch_id     SERIAL PRIMARY KEY,
    mismatch_type   VARCHAR(50),
    symbol          VARCHAR(20),
    detail          TEXT,
    detected_at     TIMESTAMP DEFAULT NOW()
);

-- Check 1: rows with no matching company metadata
SELECT * FROM target_schema.stock_yearly_summary
WHERE company_name IS NULL;

INSERT INTO target_schema.mismatch_report (mismatch_type, symbol, detail)
SELECT DISTINCT
    'missing_metadata' AS mismatch_type,
    symbol,
    'No matching company metadata found for this symbol' AS detail
FROM target_schema.stock_yearly_summary
WHERE company_name IS NULL;

-- Check 2: duplicate symbol-year combinations (aggregation integrity)
INSERT INTO target_schema.mismatch_report (mismatch_type, symbol, detail)
SELECT
    'duplicate_check',
    symbol,
    'Symbol has ' || COUNT(*) || ' rows for the same year: ' || trade_year
FROM target_schema.stock_yearly_summary
GROUP BY symbol, trade_year
HAVING COUNT(*) > 1;

-- Check 3: metadata symbols with no corresponding price history
INSERT INTO target_schema.mismatch_report (mismatch_type, symbol, detail)
SELECT
    'unused_metadata',
    m."Symbol",
    'Symbol exists in metadata but has no price history'
FROM source_schema.stock_metadata m
LEFT JOIN source_schema.combined_stock_data c ON m."Symbol" = c."Symbol"
WHERE c."Symbol" IS NULL;

-- Final report
SELECT * FROM target_schema.mismatch_report;
-- Result: 3 findings
--   missing_metadata  | BAJAUTOFIN | no metadata match
--   unused_metadata   | INFRATEL   | no trading history
--   unused_metadata   | ADANIPORTS | no trading history
