-- =========================================================
-- Simulate data quality failures for testing the validation agent
-- =========================================================

-- Step 1: Snapshot the current (correct) target as "source of truth"
-- This becomes our SRC for the validation check.
CREATE TABLE target_schema.stock_yearly_summary_expected AS
SELECT * FROM target_schema.stock_yearly_summary;

-- Step 2: Corrupt the real target table to simulate pipeline failures
-- This stays as TGT for the validation check — the table we're testing.

-- Simulate a dropped record (partial load failure)
DELETE FROM target_schema.stock_yearly_summary
WHERE symbol = 'INFY' AND trade_year = 2015;

-- Simulate a value mismatch (bad transform / stale aggregation)
UPDATE target_schema.stock_yearly_summary
SET avg_close   = avg_close + 50,
    total_volume = total_volume - 1000
WHERE symbol = 'TCS' AND trade_year = 2018;

-- Sanity check: row counts should now differ by 1
SELECT 'expected' AS which, COUNT(*) FROM target_schema.stock_yearly_summary_expected
UNION ALL
SELECT 'actual', COUNT(*) FROM target_schema.stock_yearly_summary;
