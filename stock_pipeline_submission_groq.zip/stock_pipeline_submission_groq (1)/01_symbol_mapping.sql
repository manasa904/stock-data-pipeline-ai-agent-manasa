-- =========================================================
-- STEP 1: Symbol reconciliation (crosswalk table)
-- Resolves ticker symbols that were renamed or merged across
-- the 2000-2021 timeframe of combined_stock_data.
-- =========================================================

CREATE TABLE source_schema.symbol_map (
    raw_symbol       VARCHAR(20) PRIMARY KEY,
    canonical_symbol VARCHAR(20) NOT NULL
);

INSERT INTO source_schema.symbol_map (raw_symbol, canonical_symbol) VALUES
    ('INFOSYSTCH', 'INFY'),
    ('HEROHONDA',  'HEROMOTOCO'),
    ('HINDALC0',   'HINDALCO'),
    ('HINDLEVER',  'HINDUNILVR'),
    ('TELCO',      'TATAMOTORS'),
    ('TISCO',      'TATASTEEL'),
    ('UTIBANK',    'AXISBANK'),
    ('JSWSTL',     'JSWSTEEL'),
    ('KOTAKMAH',   'KOTAKBANK'),
    ('ZEETELE',    'ZEEL'),
    ('BHARTI',     'BHARTIARTL'),
    ('SESAGOA',    'VEDL'),
    ('SSLT',       'VEDL'),
    ('UNIPHOS',    'UPL');

-- Check join coverage after applying the mapping
SELECT
    COUNT(*) AS total_rows,
    COUNT(m."Symbol") AS matched_rows,
    ROUND(100.0 * COUNT(m."Symbol") / COUNT(*), 1) AS match_pct
FROM source_schema.combined_stock_data c
LEFT JOIN source_schema.symbol_map sm
    ON c."Symbol" = sm.raw_symbol
LEFT JOIN source_schema.stock_metadata m
    ON COALESCE(sm.canonical_symbol, c."Symbol") = m."Symbol";
-- Result: 231,870 total rows, 229,259 matched (98.9%)
-- Remaining gap: BAJAUTOFIN (ambiguous 2007-08 demerger, left unresolved)
