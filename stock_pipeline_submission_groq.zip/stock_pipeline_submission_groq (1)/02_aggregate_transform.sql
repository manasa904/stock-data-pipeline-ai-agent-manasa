-- =========================================================
-- STEP 2: Aggregate & transform
-- Joins prices + metadata through the symbol map and builds
-- the target table: one row per company per year.
-- =========================================================

CREATE TABLE target_schema.stock_yearly_summary AS
SELECT
    COALESCE(sm.canonical_symbol, c."Symbol")   AS symbol,
    m."Company Name"                             AS company_name,
    m."Industry"                                 AS industry,
    EXTRACT(YEAR FROM c."Date"::date)             AS trade_year,
    COUNT(*)                                      AS trading_days,
    ROUND(AVG(c."Open")::numeric, 2)              AS avg_open,
    ROUND(AVG(c."Close")::numeric, 2)             AS avg_close,
    ROUND(MAX(c."High")::numeric, 2)              AS year_high,
    ROUND(MIN(c."Low")::numeric, 2)               AS year_low,
    SUM(c."Volume")                               AS total_volume
FROM source_schema.combined_stock_data c
LEFT JOIN source_schema.symbol_map sm
    ON c."Symbol" = sm.raw_symbol
LEFT JOIN source_schema.stock_metadata m
    ON COALESCE(sm.canonical_symbol, c."Symbol") = m."Symbol"
GROUP BY
    COALESCE(sm.canonical_symbol, c."Symbol"),
    m."Company Name",
    m."Industry",
    EXTRACT(YEAR FROM c."Date"::date);

-- Sanity checks
SELECT * FROM target_schema.stock_yearly_summary
ORDER BY symbol, trade_year
LIMIT 20;

SELECT COUNT(*) FROM target_schema.stock_yearly_summary;
-- Result: 978 rows
