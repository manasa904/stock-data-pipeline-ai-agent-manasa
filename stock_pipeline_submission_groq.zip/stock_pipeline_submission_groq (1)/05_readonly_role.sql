-- =========================================================
-- Read-only role for the validation agent
-- Grants SELECT-only access to source and target schemas.
-- Run this as the master user (postgres / sourcetargetdb).
-- =========================================================

CREATE ROLE validation_agent WITH LOGIN PASSWORD 'choose-a-strong-password-here';

GRANT CONNECT ON DATABASE source_target_db TO validation_agent;

GRANT USAGE ON SCHEMA source_schema TO validation_agent;
GRANT USAGE ON SCHEMA target_schema TO validation_agent;

GRANT SELECT ON ALL TABLES IN SCHEMA source_schema TO validation_agent;
GRANT SELECT ON ALL TABLES IN SCHEMA target_schema TO validation_agent;

-- Make sure future tables in these schemas are also readable
-- without having to re-run GRANT every time a new table is created
ALTER DEFAULT PRIVILEGES IN SCHEMA source_schema
    GRANT SELECT ON TABLES TO validation_agent;
ALTER DEFAULT PRIVILEGES IN SCHEMA target_schema
    GRANT SELECT ON TABLES TO validation_agent;

-- Sanity check: confirm the role has no write privileges
SELECT grantee, table_schema, table_name, privilege_type
FROM information_schema.role_table_grants
WHERE grantee = 'validation_agent';
